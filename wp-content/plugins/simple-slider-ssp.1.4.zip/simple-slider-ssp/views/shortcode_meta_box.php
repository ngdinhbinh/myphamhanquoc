<input type="text" style="width: 98%" id="shortcode_text_input" value="<?php echo $shortcode ?>" readonly="true" />
<p class="description">
	<br />
	<code>
		<strong style="font-size: 15px; font-style: normal"><?php _e( 'size =', 'ssp' ) ?></strong>
		<?php _e( 'thumbnail or medium or large or full', 'ssp' ) ?>
	</code>
</p>
<br />
<p class="description">
<?php _e( 'To insert a slider, simply paste the above shortcode in the post or page content editor', 'ssp' ) ?>
</p>